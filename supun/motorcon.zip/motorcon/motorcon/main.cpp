/*
 * motorcon.cpp
 *
 * Created: 1/31/2022 7:46:47 PM
 * Author : dilan
 */ 
#define F_CPU 8000000
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include <util/delay.h>
#include "LCDI2C.h"
void InitADC();

volatile uint16_t tempNum;
volatile uint8_t counter=0;
volatile uint16_t lastsave=0;
volatile uint16_t finale=0;
char txdatata[20];

int main(void)
{
    InitADC();
	//SoftUART_Init();
	//SoftUSART_tx_strln("started");
	DDRB|=(1<<0);// motor as output
	PORTB&=~(1<<0);//motor off
	//PORTB|=(1<<0);
	PORTB|=(1<<5);// pin pull up
	LcdInit();
	LcdSetCursor(1,0,"FYP Water Pump");
	_delay_ms(2000);
	sei();
    while (1) 
    {	
		
		if (!(PINB&(1<<5)))//switch on 0?
		{PORTB|=(1<<0);//motor on
			_delay_ms(2000);
		}
		//finale=30;
		float cal=(finale*1000)/220;
		sprintf(txdatata,"C %.2fmA P %02uW       ",cal,finale);
		LcdSetCursor(0,0,txdatata);
		
		if (finale<30)
		{PORTB&=~(1<<0);
		}
		
		_delay_ms(500);
		
		
		//sprintf(txdatata,"%u",finale);
		//SoftUSART_tx_strln(txdatata);
		
    }
}

void InitADC()  //meter reading initialized
{
	// Select Vref=AVcc
	ADMUX |= (1<<REFS0)|(1<<REFS1);
	//set prescaller to 128 and enable ADC
	ADCSRA |= (1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0)|(1<<ADEN);
	ADCSRA|=(1<<ADIE);// intruppet
	ADMUX = (ADMUX & 0xF0) | (1 & 0x0F);
	ADCSRA |= (1<<ADSC);
}

ISR(ADC_vect){
	
	tempNum=ADC;//30
	if (tempNum>lastsave)
	{lastsave=tempNum;
	}
	counter++;
	if (counter>200)
	{finale=lastsave;
		lastsave=0;
		counter=0;
		
	}
		
	

	ADCSRA |= (1<<ADSC);
	
	
	
}