#define F_CPU 8000000
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

volatile char letter=0;

int main(void)
{	
	DDRF|=(0b111);
	UCSR0B|=(1<<RXCIE0)|(1<<RXEN0)|(1<<RXB80);
	UCSR0C|=(1<<UCSZ01)|(1<<UCSZ00);
	UBRR0=207;
	
	DDRE|=(1<<3);
	TCCR3A|=(1<<COM3A1)|(1<<WGM30);
	TCCR3B|=(1<<CS30);
	TCCR3C|=(1<<FOC3A);
	OCR3A=0;
	sei();
    while (1) 
    {
	if (letter)
	{	uint8_t pwm=50;
		if(letter=='A'){
		PORTF=0b001;
			if (OCR3A)
			{OCR3A=0;
			} 
			else
			{OCR3A=255;
			}
		
		}
		
		else if(letter=='B'){
			PORTF=0b010;
			if (OCR3A<=(255-pwm))
			{OCR3A+=pwm;
			}
		}
		
		else if(letter=='C'){
			PORTF=0b100;
			if (OCR3A>=pwm)
			{OCR3A-=pwm;
			}
		}
		_delay_ms(50);	
		letter=0;
		UCSR0B|=(1<<RXEN0);
	}
	
	else{
	PORTF=0b000;	
	}
		_delay_ms(100);
    }
}

ISR(USART0_RX_vect){
	
	letter=UDR0;
	UCSR0B&=~(1<<RXEN0);
}

