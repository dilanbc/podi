#define F_CPU 8000000
#include <avr/io.h>


int main(void)
{
    
    while (1) 
    {
    }
}

