#define F_CPU 8000000
#include <avr/io.h>
#include <util/delay.h>
#include "USART.h"

int main(void)
{
    USART_Init(9600);
	_delay_ms(500);
	USART_TxStringln("AT");
	_delay_ms(500);
	USART_TxStringln("AT");
	_delay_ms(500);
	USART_TxStringln("AT+CMGF=1");
    while (1) 
    {
    }
}

