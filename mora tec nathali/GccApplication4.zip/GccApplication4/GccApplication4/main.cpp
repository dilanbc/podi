#define F_CPU 8000000
#include <avr/io.h>
#include <util/delay.h>

void stepper(uint16_t rev,bool dir){
	for(uint16_t j=0;j<rev;j++){
		//4,4+5,5,5+6,6,6+7,7,7+4
		if (dir)
		{for(uint8_t i=4;i<8;i++){
			PORTD=(PORTD&0x0F)|(1<<i);
			_delay_ms(100);
			if (i==7)
			{PORTD|=(1<<4);
			}
			else
			{PORTD|=(1<<i+1);
			}
			_delay_ms(100);
		}
	}
	else
	{for(uint8_t i=7;i>3;i--){
		PORTD=(PORTD&0x0F)|(1<<i);
		_delay_ms(100);
		if (i==7)
		{PORTD|=(1<<7);
		}
		else
		{PORTD|=(1<<i-1);
		}
		_delay_ms(100);
	}
}



}

}

int main(void)
{
    DDRD|=0xF0;
	stepper(5,1);
    while (1) 
    {
    }
}

