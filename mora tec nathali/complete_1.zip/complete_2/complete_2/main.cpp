// Program for Slave mode
#define F_CPU 8000000
#include <avr/io.h>
#include <util/delay.h>

void init_slave(void);
uint8_t read_data(void);
void slave_listen(void);

unsigned char recv_data;

int main(void)
{

	DDRA=0xFF;
	init_slave();
	while(1)
	{
		
		slave_listen();
		read_data();
		PORTA=recv_data;
		
	}
}

void init_slave(void)
{
	TWAR=0x20;
}

void slave_listen(void)
{
	TWCR=(1<<TWINT)|(1<<TWEA)|(1<<TWEN);
	while (!(TWCR & (1<<TWINT)));
}


uint8_t read_data(void)
{
	TWCR=(1<<TWINT)|(1<<TWEA)|(1<<TWEN);
	while (!(TWCR & (1<<TWINT)));
	recv_data=TWDR;
	return TWDR;
}