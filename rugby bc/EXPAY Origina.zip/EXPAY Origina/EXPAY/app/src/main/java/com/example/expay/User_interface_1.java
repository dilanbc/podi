package com.example.expay;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class User_interface_1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_interface1);
    }
}