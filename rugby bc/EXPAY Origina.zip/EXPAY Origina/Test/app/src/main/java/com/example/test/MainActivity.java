package com.example.test;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
EditText txt_name,txt_username;
Button btn;
//FirebaseDatabase rootNode;
//DatabaseReference reference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt_name=findViewById(R.id.name);
        txt_username=findViewById(R.id.username);
        btn=findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                save();
            }
        });
    }
    private boolean save()
    {

        String username=txt_username.getText().toString();
        DatabaseReference reference=FirebaseDatabase.getInstance().getReference().child("Users").child(username);
        reference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull  DataSnapshot snapshot) {

              if(snapshot.hasChildren())
              {
                  Toast.makeText(getApplicationContext(),"Data Already Exits",Toast.LENGTH_LONG).show();
              }
              else
              {String name=txt_name.getText().toString();
                  String username=txt_username.getText().toString();
                  FirebaseDatabase rootNode;
                  DatabaseReference reference;
                  rootNode=FirebaseDatabase.getInstance();
                  reference=rootNode.getReference("Users");
                  UserHelperClass helperClass=new UserHelperClass(name,username);
                  reference.child(username).setValue(helperClass);
                  Toast.makeText(getApplicationContext(),"Successfully Saved",Toast.LENGTH_LONG).show();

              }
            }

            @Override
            public void onCancelled(@NonNull  DatabaseError error) {

            }
        });


return  true;

    }
}